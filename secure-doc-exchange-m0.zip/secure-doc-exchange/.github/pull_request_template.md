## What this PR does

<!-- One or two sentences. Link the milestone, e.g. "Milestone 1: RSA-PSS sign/verify". -->

## How I tested it

- [ ] `python -m pytest` passes on my machine (OS: macOS / Windows)
- [ ] I ran any new feature by hand where relevant

## Safety checklist

- [ ] No files from `keys/`, no `.pem` files, no `.env` files in this PR
- [ ] No private keys, AES keys or plaintext printed or logged
- [ ] No test results written down that I did not actually run

## Reviewer

<!-- Who should review this? The reviewer must be able to explain the change. -->
